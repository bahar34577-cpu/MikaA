// Global runtime config (safe to ship). For secrets, use server-side .env
// This file is loaded BEFORE app.js

window.APP_CONFIG = {
  api: {
    // Recommended: keep true so API keys never appear in browser source.
    useProxy: true,
    // If you host the API somewhere else, set full URL e.g. "https://domain.com"
    proxyBase: "",
  },
  deposit: {
    // Minimum deposit (in IDR)
    minAmount: 10000,
    // Admin fee = max(minFee, round(amount * percent))
    adminFeePercent: 0.02,
    adminFeeMin: 1000,
    // Default QR expiry (seconds) used when provider doesn't send expiry
    expirySeconds: 5 * 60,
  }
};
